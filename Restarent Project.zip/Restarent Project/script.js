var wrapper = document.querySelector('.wrapper');
var but = document.querySelector('.but');
var iconclose = document.querySelector('.icon-close');
var button = document.getElementById('btn');

but.addEventListener('click', function () {
    wrapper.classList.add('active-popup');
});

iconclose.addEventListener('click', function () {
    wrapper.classList.remove('active-popup');
});

button.onclick = function () {
        document.write('No Tables Available');
}


